# New Bharat Medical Store v2 Android project

Includes updated pharmacy branding/logo. Customer-facing inventory addition controls are hidden in this prototype. A real admin inventory feature must use secure server-side authentication and authorization; this prototype does not provide that backend. Prescription selection is not a secure upload service and WhatsApp ordering requires configuring the store number and explicit customer action. Sample products/prices are for demonstration only.

Build with GitHub Actions or Android Studio using Java 17 and Gradle 8.9.
