# New Bharat Medical Store — Firebase-connected Android starter

Package: `com.newbharat.medicalstore`  
Firebase project: `new-bharat-medical-store`

This is a real Android source project (not the previous WebView mock-up). It includes Firebase Phone Authentication, Firestore-backed medicine listings, customer order creation/history, and an admin dashboard for adding/deactivating listings and accepting/rejecting orders.

## Included now
- Firebase Android configuration (`app/google-services.json`) for the new Firebase project.
- Phone OTP sign-in using Firebase Authentication.
- Customer catalogue, cart, COD order request and order history.
- Admin view gated by an `admins/{uid}` Firestore document with `active: true`.
- Admin add/deactivate medicine and update order status.
- Firestore and Storage rules templates.
- GitHub Actions APK build and signing-report workflow.

## Required Firebase setup before use
1. In Firebase Console → Project settings → Your apps → Android app, add the SHA-1 fingerprint from the GitHub Actions `Android-SHA1-signing-report` artifact. Rebuild after adding it.
2. Authentication → Phone provider must be enabled. Add a test phone only for testing if needed; real SMS quotas/billing/region settings are controlled by Firebase.
3. Firestore → Rules: publish `firestore.rules` from this project. Do not use public read/write rules.
4. Storage → Rules: publish `storage.rules` before enabling prescription uploads.
5. After the administrator has signed in once, obtain that user's Firebase UID from Authentication → Users. In Firestore create collection `admins`, document ID equal to that UID, fields: `active` (boolean) = `true`, `phone` (string) = `+919455612222`. This is a one-time owner action; never grant admin by trusting a phone number sent by the app.
6. Keep the project on Spark until you understand any billing requirements. Firebase Phone Auth SMS, Cloud Storage availability/requirements, and usage limits can change; check console billing notices before enabling paid services.

## Important current limitations
This is the first Firebase-connected functional foundation, not yet a production pharmacy release. Prescription upload UI/workflow, online payments, delivery-zone/rate engine, invoice generation, medicine batch/expiry ledger, stock decrement/transaction validation, pharmacist verification, push notifications, and audit logs still need implementation and testing. The current COD order is a request pending pharmacy review, not a confirmed sale. Do not use it for real medicine sales until pharmacy compliance, data protection, rules, and end-to-end testing are completed.

## Build
GitHub Actions runs `gradle assembleDebug` on push or manual dispatch. Download the artifact `New-Bharat-Medical-Store-Firebase-APK`.
