# New Bharat Medical Store — Android starter project

This is an Android Studio project wrapping the mobile-friendly prototype in a WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the IDE.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a phone install, use the generated debug APK and allow installation from that source if Android asks.

## Current limitations
- This is a prototype wrapper, not a production pharmacy platform.
- Product data and cart are demo-only; there is no live database, secure admin login, payment, actual order submission, prescription upload server, or delivery integration.
- The prescription selector currently only selects a local file; it does not transmit it.
- Do not use this build to sell or dispense medicines. Before launch, implement secure backend services and verify applicable pharmacy/drug-sale, prescription, privacy, and delivery requirements.

## Store details in this prototype
- Name: New Bharat Medical Store
- Base location: Ghosi, Mau, Uttar Pradesh
- Planned service districts: Mau, Ballia, Azamgarh, Gorakhpur, Ghazipur
